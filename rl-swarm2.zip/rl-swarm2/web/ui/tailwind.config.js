module.exports = {
	theme: {
		extend: {
			fontSize: {
				base: '14px',
			},
		},
	},
	plugins: [],
}
